from setuptools import setup

setup(
    nombre="Elmor_Marketplace",
    version="2.0",
    descripcion="Agregue un marketplace a Elmor Plus",
    autor="Fabian Oscar Frias",
    autorEmail="fabianfrias25@gmail.com",
    packages=["Elmor_Marketplace"]
    )